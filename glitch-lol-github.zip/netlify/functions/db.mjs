// Shared storage for glitch-lol (profiles, view counters, staff, uploaded files).
// Data lives in Netlify Blobs. Optional env var ADMIN_TOKEN enables staff/admin actions.
import { getStore } from "@netlify/blobs";
import { createHash } from "node:crypto";

const COLS = new Set(["profiles", "seen", "staff", "disc"]); // "disc" = Discord badge flags, written only by the discord function
const MAX_DOC = 600 * 1024;
const CK = 3 * 1024 * 1024, MAX_BIG = 1024 * 1024 * 1024;
const MAX_FILE = 4.5 * 1024 * 1024; // Netlify functions accept at most ~6 MB per request/response
const OK_TYPES = /^(image\/(png|jpeg|gif|webp)|video\/(mp4|webm|quicktime)|audio\/[\w.+-]+)$/;

// Unpublished profiles (drafts) are only visible to their owner; deleted profiles (name reserved) to nobody.
const visible = (d, me, admin) => d && !d.deleted && (d.pub !== false || admin || (me && d.owner === me));

// Owner ids double as login secrets, so they never leave the server in clear text (viewers only see a hash).
const oh = (s) => "h" + createHash("sha256").update("o|" + s).digest("hex").slice(0, 24);
const pubDoc = (c, d, me) => (c === "profiles" && d && d.owner && d.owner !== me ? { ...d, owner: oh(d.owner) } : d);

// HTTP Range support so <video>/<audio> can stream big files piece by piece
const rangeOf = (req, total, cap = Infinity) => {
  const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.get("range") || "");
  if (!m || (m[1] === "" && m[2] === "")) return null;
  const a = m[1] === "" ? Math.max(0, total - +m[2]) : +m[1], z = m[2] === "" || m[1] === "" ? total - 1 : Math.min(+m[2], total - 1);
  if (a >= total || a > z) return [-1, -1];
  return [a, Math.min(z, a + cap - 1)];
};
const part = (buf, type, [a, z], total) => new Response(buf, { status: 206, headers: { "content-type": type, "content-range": `bytes ${a}-${z}/${total}`, "content-length": String(z - a + 1), "accept-ranges": "bytes", "cache-control": "private, max-age=86400", "x-content-type-options": "nosniff" } });
const bad416 = (total) => new Response(null, { status: 416, headers: { "content-range": "bytes */" + total } });

const json = (o, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

// Each collection is one JSON blob {id: doc}. Writes use a compare-and-swap retry loop.
async function mutate(store, col, fn) {
  for (let i = 0; i < 8; i++) {
    const cur = await store.getWithMetadata("col/" + col, { type: "json" });
    const data = (cur && cur.data) || {};
    const res = fn(data);
    if (res && res.error) return res;
    const opts = cur && cur.etag ? { onlyIfMatch: cur.etag } : { onlyIfNew: true };
    const w = await store.setJSON("col/" + col, data, opts);
    if (w && w.modified === false) continue;
    return { ok: true };
  }
  return { error: "busy", status: 503 };
}

// One profile per IP address. Only a salted hash of the IP is stored (collection "ips", never exposed to clients).
const ipHash = (ip) =>
  createHash("sha256").update((process.env.IP_SALT || "glitchbio") + "|" + ip).digest("hex").slice(0, 40);


// CORS: lets the GitHub Pages copy of the site talk to this backend. Set ALLOWED_ORIGINS (comma separated) to restrict; default allows any origin.
const corsH = (req) => {
  const o = req.headers.get("origin") || "";
  const list = (process.env.ALLOWED_ORIGINS || "").split(",").map((x) => x.trim()).filter(Boolean);
  const allow = !list.length ? (o || "*") : list.includes(o) ? o : "";
  return allow ? { "access-control-allow-origin": allow, "access-control-allow-headers": "content-type,x-me,x-admin,range", "access-control-allow-methods": "GET,POST,OPTIONS", "access-control-expose-headers": "content-range,accept-ranges,content-length", "vary": "origin" } : {};
};
const withCors = (fn) => async (req, context) => {
  const h = corsH(req);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: { ...h, "access-control-max-age": "86400" } });
  const res = await fn(req, context);
  for (const k of Object.keys(h)) res.headers.set(k, h[k]);
  return res;
};

export default withCors(async (req, context) => {
  const url = new URL(req.url);
  const store = getStore({ name: "glitchbio", consistency: "strong" });
  const me = (req.headers.get("x-me") || "").slice(0, 64);
  const tok = process.env.ADMIN_TOKEN || "";
  const admin = !!tok && req.headers.get("x-admin") === tok;
  const ip = (context && context.ip) || (req.headers.get("x-nf-client-connection-ip") || "").trim() ||
    (req.headers.get("x-forwarded-for") || "").split(",")[0].trim();

  // serve an uploaded file
  if (req.method === "GET") {
    const id = url.searchParams.get("asset");
    if (!id || !/^[\w-]{8,64}$/.test(id)) return new Response("Not found", { status: 404 });
    const man = await store.get("assetm/" + id, { type: "json" });
    if (man) {
      const rg = rangeOf(req, man.size, CK) || [0, Math.min(man.size, CK) - 1];
      if (rg[0] < 0) return bad416(man.size);
      const parts = [], k0 = Math.floor(rg[0] / CK);
      for (let k = k0; k <= Math.floor(rg[1] / CK); k++) {
        const pc = await store.get("assets/" + id + "/" + k, { type: "arrayBuffer" });
        if (!pc) return new Response("Not found", { status: 404 });
        parts.push(Buffer.from(pc));
      }
      return part(Buffer.concat(parts).subarray(rg[0] - k0 * CK, rg[1] - k0 * CK + 1), man.type, rg, man.size);
    }
    const f = await store.getWithMetadata("assets/" + id, { type: "arrayBuffer" });
    if (!f) return new Response("Not found", { status: 404 });
    const rg1 = rangeOf(req, f.data.byteLength);
    if (rg1) {
      if (rg1[0] < 0) return bad416(f.data.byteLength);
      return part(Buffer.from(f.data.slice(rg1[0], rg1[1] + 1)), (f.metadata && f.metadata.type) || "application/octet-stream", rg1, f.data.byteLength);
    }
    return new Response(f.data, {
      headers: {
        "content-type": (f.metadata && f.metadata.type) || "application/octet-stream",
        "cache-control": "public, max-age=31536000, immutable",
        "x-content-type-options": "nosniff",
        "netlify-vary": "query=asset", // every ?asset=<id> is its own cached file on Netlify's CDN
      },
    });
  }
  if (req.method !== "POST") return json({ error: "method" }, 405);

  // big file: stored as 3 MB pieces + a manifest (never assembled in memory); the last piece publishes it
  if (url.searchParams.get("op") === "chunk") {
    const type = (req.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    if (!me) return json({ error: "identity" }, 400);
    if (!OK_TYPES.test(type)) return json({ error: "type" }, 415);
    const cid = url.searchParams.get("id") || "", i = +url.searchParams.get("i"), n = +url.searchParams.get("n"), s = +url.searchParams.get("s");
    if (!/^[\w-]{8,64}$/.test(cid) || !(n >= 1 && n <= 342 && i >= 0 && i < n) || !(s > 0 && s <= MAX_BIG) || n !== Math.ceil(s / CK)) return json({ error: "chunk" }, 400);
    if (await store.get("assetm/" + cid, { type: "json" })) return json({ error: "exists" }, 409);
    const buf = await req.arrayBuffer();
    if (!buf.byteLength || buf.byteLength > CK || (i < n - 1 && buf.byteLength !== CK)) return json({ error: "size" }, 413);
    await store.set("assets/" + cid + "/" + i, buf);
    if (i === n - 1) await store.setJSON("assetm/" + cid, { type, size: s, n });
    return json(i === n - 1 ? { url: "/.netlify/functions/db?asset=" + cid } : { ok: true });
  }

  // upload a file
  if (url.searchParams.get("op") === "upload") {
    const type = (req.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
    if (!me) return json({ error: "identity" }, 400);
    if (!OK_TYPES.test(type)) return json({ error: "type" }, 415);
    const buf = await req.arrayBuffer();
    if (!buf.byteLength || buf.byteLength > MAX_FILE) return json({ error: "size" }, 413);
    const id = crypto.randomUUID();
    await store.set("assets/" + id, buf, { metadata: { type } });
    return json({ url: "/.netlify/functions/db?asset=" + id }); // relative: works on every domain of the site
  }

  let b;
  try { b = await req.json(); } catch { return json({ error: "body" }, 400); }
  const { op, c, id } = b || {};
  if (op === "whoami") return json({ admin, configured: !!tok }); // lets the site check the editor token
  if (op === "multi") {
    const out = {};
    for (const x of Array.isArray(b.cols) ? b.cols.slice(0, 4) : []) {
      if (!x || !COLS.has(x.c)) continue;
      const all = (await store.get("col/" + x.c, { type: "json" })) || {};
      const lim = Math.min(Math.max(+x.limit || 200, 1), 1000);
      out[x.c] = Object.keys(all).filter((k) => visible(all[k], me, admin)).slice(0, lim).map((k) => ({
        id: x.c === "seen" ? oh(k) : k, // view counters are keyed by visitor id: hash it
        data: x.c === "seen" ? { c: all[k].c || {} } : pubDoc(x.c, all[k], me), // view counters: drop timestamps to keep it small
      }));
    }
    return json({ cols: out });
  }

  // download an uploaded file in chunks over the normal JSON API (same route the profile data uses; works everywhere, no range/CDN/query-string quirks)
  if (op === "asset") {
    const aid = String(b.id || "");
    if (!/^[\w-]{8,64}$/.test(aid)) return json({ error: "id" }, 400);
    const man = await store.get("assetm/" + aid, { type: "json" });
    if (man) {
      const off = Math.max(0, Math.floor((+b.off || 0) / CK) * CK), pc = await store.get("assets/" + aid + "/" + off / CK, { type: "arrayBuffer" });
      if (!pc) return json({ error: "notfound" }, 404);
      return json({ type: man.type, size: man.size, off, b64: Buffer.from(pc).toString("base64") });
    }
    const f = await store.getWithMetadata("assets/" + aid, { type: "arrayBuffer" });
    if (!f || !f.data) return json({ error: "notfound" }, 404);
    const CH = CK, total = f.data.byteLength, off = Math.max(0, +b.off || 0), len = Math.min(Math.max(+b.len || CH, 1), CH);
    return json({ type: (f.metadata && f.metadata.type) || "application/octet-stream", size: total, off, b64: Buffer.from(f.data.slice(off, off + len)).toString("base64") });
  }

  if (!COLS.has(c)) return json({ error: "collection" }, 400);

  if (op === "list") {
    const cur = await store.get("col/" + c, { type: "json" });
    const all = cur || {};
    const lim = Math.min(Math.max(+b.limit || 200, 1), 1000);
    const docs = Object.keys(all).filter((k) => visible(all[k], me, admin)).slice(0, lim).map((k) => ({ id: k, data: pubDoc(c, all[k], me) }));
    return json({ docs });
  }

  if (!id || !/^[\w-]{1,64}$/.test(id)) return json({ error: "id" }, 400);

  if (op === "get") {
    const cur = await store.get("col/" + c, { type: "json" });
    const d = cur && cur[id];
    if (c === "profiles" && d && d.pub === false && !d.deleted && !admin && d.owner !== me)
      return json({ exists: true, data: { user: id, owner: oh(d.owner), saved: false, private: true } }); // draft: name stays taken, content hidden
    return json({ exists: !!d, data: pubDoc(c, d, me) || null });
  }

  if (op === "set") {
    const data = b.data;
    if (!data || typeof data !== "object" || JSON.stringify(data).length > MAX_DOC) return json({ error: "data" }, 400);
    // --- one profile per IP (new claims and renames) ---
    let ipKey = null, ipPrev;
    if (c === "profiles" && !admin) {
      if (!me || me.length < 16) return json({ error: "identity" }, 400); // no per-browser id -> no profile
      if (!ip) return json({ error: "ip_limit" }, 403);
      ipKey = ipHash(ip);
      const profs = (await store.get("col/profiles", { type: "json" })) || {};
      const ipr = await mutate(store, "ips", (m) => {
        const cur = m[ipKey];
        ipPrev = cur;
        if (cur && cur.user !== id) {
          const old = profs[cur.user];
          // this IP already has a different profile: only its owner may move it (rename) while it is still live
          if (cur.owner !== me || !old || old.deleted) return { error: "ip_limit", status: 403 };
        }
        m[ipKey] = { user: id, owner: me, t: Date.now() };
      });
      if (ipr.error) return json({ error: ipr.error }, ipr.status || 400);
    }
    const r = await mutate(store, c, (all) => {
      const ex = all[id];
      if ((c === "staff" || c === "disc") && !admin) return { error: "forbidden", status: 403 };
      if (c === "seen" && !admin && id !== me) return { error: "forbidden", status: 403 };
      if (c === "profiles" && !admin) {
        if (!/^[a-z0-9_]{2,20}$/.test(id)) return { error: "id", status: 400 };
        if (!me || data.owner !== me || data.user !== id) return { error: "forbidden", status: 403 };
        if (ex && ex.owner && ex.owner !== me) return { error: "taken", status: 403 };
      }
      all[id] = data;
    });
    if (r.error && ipKey) {
      // profile write failed (e.g. name taken): give the IP slot back
      await mutate(store, "ips", (m) => { if (ipPrev) m[ipKey] = ipPrev; else delete m[ipKey]; });
    }
    if (!r.error && c === "profiles" && !admin) {
      // carry over Discord badges the owner already earned (server-side flags, never taken from the client)
      const f = await store.get("dcme/" + oh(me), { type: "json" });
      if (f) await mutate(store, "disc", (m) => { m[id] = { m: f.m, s: f.s, d: f.d || "", t: f.t }; });
    }
    return r.error ? json({ error: r.error }, r.status || 400) : json({ ok: true });
  }

  if (op === "delete") {
    const r = await mutate(store, c, (all) => {
      const ex = all[id];
      if (!ex) return;
      if (!admin) {
        if (c !== "profiles" || !me || ex.owner !== me) return { error: "forbidden", status: 403 };
      }
      if (c === "profiles" && !admin) {
        // the name stays reserved for its owner forever; only the profile content goes away
        all[id] = { user: id, owner: ex.owner, saved: false, deleted: true, updated: Date.now() };
      } else {
        delete all[id]; // only an admin can free a name or remove other data
      }
    });
    return r.error ? json({ error: r.error }, r.status || 400) : json({ ok: true });
  }

  return json({ error: "op" }, 400);
});
