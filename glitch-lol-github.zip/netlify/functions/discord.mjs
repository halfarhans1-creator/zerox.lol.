// Discord login for glitch-lol: links a website profile to a Discord account once.
// After that the bot (discord-sync.mjs) keeps the badges up to date automatically.
// Netlify env vars:
//   DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET   (Developer Portal -> your application -> OAuth2)
//   DISCORD_GUILD_ID                           (your server id)
//   DISCORD_STAFF_ROLE_IDS                     (staff role id(s), comma separated)
//   DISCORD_BOT_TOKEN                          (Developer Portal -> Bot; the bot must be in your server)
// Optional: DISCORD_REDIRECT_URI (default <site>/.netlify/functions/discord; add it under OAuth2 -> Redirects)
import { getStore } from "@netlify/blobs";
import { randomUUID } from "node:crypto";
import { H, mutate, memberFlags, applyMany } from "./lib/dc.mjs";

const json = (o, status = 200) =>
  new Response(JSON.stringify(o), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });


// CORS: lets the GitHub Pages copy of the site talk to this backend. Set ALLOWED_ORIGINS (comma separated) to restrict; default allows any origin.
const corsH = (req) => {
  const o = req.headers.get("origin") || "";
  const list = (process.env.ALLOWED_ORIGINS || "").split(",").map((x) => x.trim()).filter(Boolean);
  const allow = !list.length ? (o || "*") : list.includes(o) ? o : "";
  return allow ? { "access-control-allow-origin": allow, "access-control-allow-headers": "content-type,x-me,x-admin,range", "access-control-allow-methods": "GET,POST,OPTIONS", "access-control-expose-headers": "content-range,accept-ranges,content-length", "vary": "origin" } : {};
};
const withCors = (fn) => async (req, context) => {
  const h = corsH(req);
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: { ...h, "access-control-max-age": "86400" } });
  const res = await fn(req, context);
  for (const k of Object.keys(h)) res.headers.set(k, h[k]);
  return res;
};

export default withCors(async (req) => {
  const url = new URL(req.url);
  const E = process.env;
  const op = url.searchParams.get("op");
  const store = getStore({ name: "glitchbio", consistency: "strong" });
  const back = (r) => new Response(null, { status: 302, headers: { location: "/?dc=" + r + "#/account/settings", "cache-control": "no-store" } });
  const cid = E.DISCORD_CLIENT_ID, sec = E.DISCORD_CLIENT_SECRET, gid = E.DISCORD_GUILD_ID;
  const redirect = E.DISCORD_REDIRECT_URI || url.origin + "/.netlify/functions/discord";
  const meOf = (req) => (req.headers.get("x-me") || "").slice(0, 64);

  // the page asks for a Discord login URL (first link)
  if (req.method === "POST" && op === "start") {
    if (!cid || !sec || !gid) return json({ error: "not_configured" }, 503);
    const me = meOf(req);
    if (me.length < 16) return json({ error: "identity" }, 400);
    const st = randomUUID();
    await store.setJSON("dcstate/" + st, { me, t: Date.now() });
    const q = new URLSearchParams({ client_id: cid, redirect_uri: redirect, response_type: "code", scope: "identify guilds.members.read", state: st });
    return json({ url: "https://discord.com/oauth2/authorize?" + q });
  }

  // "Re-check" for an already linked account: no login needed, the bot looks it up
  if (req.method === "POST" && op === "recheck") {
    const me = meOf(req);
    if (me.length < 16) return json({ error: "identity" }, 400);
    if (!E.DISCORD_BOT_TOKEN) return json({ error: "no_bot" }, 503);
    const mine = H(me);
    const links = (await store.get("col/dclinks", { type: "json" })) || {};
    const id = Object.keys(links).find((k) => links[k] === mine);
    if (!id) return json({ error: "not_linked" }, 404);
    const f = await memberFlags(E, id);
    if (!f) return json({ error: "discord" }, 502);
    await applyMany(store, [{ h: mine, f }]);
    return json({ ok: true, m: f.m, s: f.s });
  }

  // Discord sends the person back here after login
  if (req.method === "GET" && (op === "cb" || url.searchParams.has("code") || url.searchParams.has("error"))) {
    if (!cid || !sec || !gid) return back("err");
    if (url.searchParams.get("error")) return back("denied");
    const code = url.searchParams.get("code"), st = url.searchParams.get("state") || "";
    if (!code || !/^[\w-]{8,64}$/.test(st)) return back("err");
    const s = await store.get("dcstate/" + st, { type: "json" });
    await store.delete("dcstate/" + st);
    if (!s || Date.now() - s.t > 10 * 60 * 1000) return back("expired");
    const mine = H(s.me);
    try {
      const tr = await fetch("https://discord.com/api/v10/oauth2/token", {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ client_id: cid, client_secret: sec, grant_type: "authorization_code", code, redirect_uri: redirect }),
      });
      if (!tr.ok) return back("err");
      const auth = { authorization: "Bearer " + (await tr.json()).access_token };
      const ur = await fetch("https://discord.com/api/v10/users/@me", { headers: auth });
      if (!ur.ok) return back("err");
      const du = await ur.json();

      // one Discord account <-> one website owner
      const links0 = (await store.get("col/dclinks", { type: "json" })) || {};
      if (links0[du.id] && links0[du.id] !== mine) return back("used");

      // roles: ask the bot if configured, otherwise use the person's own login
      let f = await memberFlags(E, du.id);
      if (!f) {
        const mr = await fetch("https://discord.com/api/v10/users/@me/guilds/" + gid + "/member", { headers: auth });
        if (mr.ok) {
          const m = await mr.json();
          const want = new Set((E.DISCORD_STAFF_ROLE_IDS || "").split(",").map((x) => x.trim()).filter(Boolean));
          f = { m: 1, s: (m.roles || []).some((r) => want.has(r)) ? 1 : 0, d: "", t: Date.now() };
        } else if (mr.status === 404) {
          let j = null;
          try { j = await mr.json(); } catch (e) { /* ignore */ }
          if (j && j.code === 10007) f = { m: 0, s: 0, d: "", t: Date.now() };
          else return back("err");
        } else return back("err");
      }
      // Discord profile frame (avatar decoration) of the linked account
      f.d = (du.avatar_decoration_data && du.avatar_decoration_data.asset) || "";
      await mutate(store, "dclinks", (m) => {
        for (const k of Object.keys(m)) if (m[k] === mine && k !== du.id) delete m[k];
        m[du.id] = mine;
      });
      await applyMany(store, [{ h: mine, f }]);
      return back(f.m ? "ok" : "nomember");
    } catch (e) {
      return back("err");
    }
  }
  return json({ error: "op" }, 400);
});
