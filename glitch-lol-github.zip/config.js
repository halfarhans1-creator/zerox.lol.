/* glitch-lol settings.
   NETLIFY: leave api empty - the backend is the same site.
   GITHUB PAGES: GitHub cannot run the backend functions, so the backend must stay on Netlify:
     api:  your Netlify site, e.g. "https://glitch-lol.netlify.app"
     base: "auto" detects "/" or "/repo-name/" itself */
window.GLITCH = {
  api: "",
  base: "auto",
  __loaded: true
};
